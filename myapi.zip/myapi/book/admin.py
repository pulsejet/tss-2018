from django.contrib import admin

from book.models import Book

admin.site.register(Book)
