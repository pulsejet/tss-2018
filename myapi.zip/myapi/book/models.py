from django.db import models

class Book(models.Model):
    name = models.CharField(max_length=30)
    description = models.TextField(blank=True)
    image_url = models.URLField(blank=True, null=True)
    code = models.IntegerField(blank=True, null=True)
    shelf = models.IntegerField()

    def __str__(self):
        return self.name
